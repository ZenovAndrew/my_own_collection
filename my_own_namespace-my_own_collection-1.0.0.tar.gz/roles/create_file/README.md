Create file with some description
=========



Requirements
------------

nothing 

Role Variables
--------------

path: # path and name of file
content: #content of file


Example Playbook
----------------

    - hosts: all
      roles:
         - create_file

License
-------

MIT

Author Information
------------------

Zenov Andrew 
